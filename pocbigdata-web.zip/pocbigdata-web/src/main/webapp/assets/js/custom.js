$(document).ready(function() {
	console.log("ready cassandra board!");

	$("#graficoRoubosMarca").hide();
	$("#graficoFaixaEtaria").hide();
	$("#graficoAcidentesPeriodo").hide();
	$("#graficoDefeitosMarca").hide();
	$("#graficoRoubosRegiao").hide();
	$("#graficoAcidentesRoubos").hide();
	
	$.ajax("http://localhost:8080/poc-bigdata/indicador").done(function(data) {
		console.log(data);
		for (var i = 0; i < data.data.length; i++) {
			if (data.data[i].tipoGrafico == "marca_roubos") {
				renderRoubosPorMarcas(data.data[i]);
			} else if(data.data[i].tipoGrafico == "marca_defeitos") {
				renderDefeitosPorMarca(data.data[i]);
			} else if(data.data[i].tipoGrafico == "faixaetaria_sinistros") {
				renderFaixaEtariaSinistros(data.data[i]);
			} else if(data.data[i].tipoGrafico == "regiao_sinistros") {
				renderRegioesSinistros(data.data[i]);
			} else if(data.data[i].tipoGrafico == "acidentes_roubos") {
				renderAcidentesRoubos(data.data[i]);
			}
		}
	}).fail(function() {
		alert("error");
	});
});

function renderRoubosPorMarcas(data) {
	if (data != null) {
		$("#graficoRoubosMarca").fadeIn("slow");
	} else {
		
	}
};

function renderDefeitosPorMarca(data) {
	if (data != null) {
		var arrayCores = ['progress-bar-green', 'progress-bar-red', 'progress-bar-cyan', 'progress-bar-amethyst', 'progress-bar-orange', 'progress-bar-green', 'progress-bar-red', 'progress-bar-cyan', 'progress-bar-amethyst', 'progress-bar-orange' ];
		var ulLabelsGrafico = $("#itensGraficoPanesMarca");
		
		var total = 0;
		for(var i = 0; i < data.itens.length; i++) {
			total = total + data.itens[i].valor;
		}
		
		for(var i = 0; i < data.itens.length; i++) {
			var itemGrafico = '<li><div class="details"><div class="title">'+data.itens[i].item+'</div></div><div class="status pull-right"><span class="animate-number" data-value="'+(data.itens[i].valor/total) * 100+'" data-animation-duration="1500">'+(data.itens[i].valor/total)*100+'</span>%</div><div class="clearfix"></div><div class="progress progress-little"><div class="progress-bar '+arrayCores[i]+' animate-progress-bar" data-percentage="'+(data.itens[i].valor/total)*100+'%" style="width: '+(data.itens[i].valor/total)*100+'%;"></div></div></li>'
			ulLabelsGrafico.append(itemGrafico);
		}
		
		$("#graficoDefeitosMarca").fadeIn("slow");
	} else {

	}
}

function renderFaixaEtariaSinistros(data) {
	if (data != null) {
		$("#graficoFaixaEtaria").fadeIn("slow");
	} else {

	}
}

function renderRegioesSinistros(data) {
	if (data != null) {
		$("#graficoRoubosRegiao").fadeIn("slow");
		
		// Roubos por Região - AmCharts
		//
		
		var itemArray = {
			id : "BR-SC",
			value : 0
		};
		
		var areas = new Array();
		
		for(var i = 0; i < data.itens.length; i++) {
			
			var itemArray = {
				id : "BR-" + data.itens[i].item,
				value : data.itens[i].valor
			};
			
			areas.push(itemArray);
			console.log(areas);
		}
		
		var map = AmCharts.makeChart("RoubosPorRegiao", {
			type : "map",
			"theme" : "default",

			colorSteps : 10,

			dataProvider : {
				map : "brazilLow",
				areas : areas
			},

			areasSettings : {
				autoZoom : false
			},

			valueLegend : {
				right : 10,
				minValue : "pouco",
				maxValue : "muito"
			},

			"export" : {
				"enabled" : true
			}
		});

		$('a[title="Interactive JavaScript maps"]').css('display', 'none');
		$('a[title="JS map by amCharts"]').css('display', 'none');
		
		
	} else {

	}
}

function renderAcidentesRoubos(data) {
	if (data != null) {
		$("#graficoAcidentesRoubos").fadeIn("slow");
		
		var arrayCores = [ '#00a3d8', '#d9544f', '#2fbbe8', '#72cae7', '#ffc100', '#1693A5' ];
		var ulLabelsGrafico = $("#itensGraficoTipoSinistro");
		
		var valores = new Array();
		var total = 0;
		for(var i = 0; i < data.itens.length; i++) {
			valores.push(parseInt(data.itens[i].valor));
			total = total + parseInt(data.itens[i].valor);
		}
		
		var cores = new Array();
		for(var i = 0; i < data.itens.length; i++) {
			cores.push(arrayCores[i]);
		}
		
		for(var i = 0; i < data.itens.length; i++) {
			ulLabelsGrafico.append('<li><span class="badge badge-outline" style="border-color: '+arrayCores[i]+'"></span>'+data.itens[i].item+'<small>'+(data.itens[i].valor/total) * 100+'%</small></li>');
		}
		
		$('#AcidentesExpressasxLocais').sparkline(valores, {
			type : 'pie',
			width : 'auto',
			height : '250px',
			sliceColors : cores
		});
		
	} else {

	}
}

// Sortable GRID
//
$(".sortable").sortable({
	connectWith : ".sortable",
	handle : ".tile-header",
	placeholder : "tile-placeholder",
	start : function() {
		$('.sortable .tile').addClass('drag-active');
	},
	stop : function() {
		$('.sortable .tile').removeClass('drag-active');
	}
}).disableSelection();


//

// Roubos Por Marca
// Morris donut chart
Morris
		.Donut({
			element : 'RoubosPorMarca',
			data : [ {
				label : "JAC Motors",
				value : 25
			}, {
				label : "Volkswagen",
				value : 20
			}, {
				label : "Chery",
				value : 15
			}, {
				label : "Fiat",
				value : 5
			}, {
				label : "Hafei",
				value : 10
			}, {
				label : "Outros",
				value : 25
			} ],
			colors : [ '#00a3d8', '#2fbbe8', '#72cae7', '#d9544f', '#ffc100',
					'#1693A5' ]
		});

$('#RoubosPorMarca').find("path[stroke='#ffffff']").attr('stroke',
		'rgba(0,0,0,0)');
//

// Morris line chart
//
Morris.Line({
	element : 'UtilizacaoDoSeguro',
	data : [ {
		y : '2012',
		a : 15,
		b : 5,
		c : 10,
		d : 20,
		e : 17
	}, {
		y : '2013',
		a : 20,
		b : 10,
		c : 15,
		d : 25,
		e : 22
	}, {
		y : '2014',
		a : 35,
		b : 20,
		c : 25,
		d : 30,
		e : 27
	}, {
		y : '2015',
		a : 30,
		b : 20,
		c : 30,
		d : 35,
		e : 30
	}, {
		y : '2016',
		a : 10,
		b : 30,
		c : 20,
		d : 15,
		e : 25
	} ],
	xkey : 'y',
	ykeys : [ 'a', 'b', 'c', 'd', 'e' ],
	labels : [ '18-25', '25-35', '35-45', '45-60', '>60' ],
	lineColors : [ '#16a085', '#FF0066', "#ffc100", "#a2d200", "#1693A5" ]
});

// Acidentes: Dia x Noite
// Sparkline Line Chart
$('#AcidentesDiaxNoite').sparkline([ 15, 25, 17, 22, 22, 27, 25, 26, 30 ], {
	type : 'line',
	width : '100%',
	height : '250px',
	fillColor : 'rgba(255, 74, 67, .6)',
	lineColor : 'rgba(255, 74, 67, .8)',
	lineWidth : 2,
	spotRadius : 5,
	valueSpots : [ 2, 3, 4, 3, 1, 2, 4, 1, 3 ],
	minSpotColor : '#ffeced',
	maxSpotColor : '#d90200',
	highlightSpotColor : '#d90200',
	highlightLineColor : '#bec6ca',
	normalRangeMin : 0
});

$('#AcidentesDiaxNoite').sparkline([ 1, 0, 2, 1, 2, 1, 2, 1, 3 ], {
	type : 'line',
	composite : true,
	width : '100%',
	height : '250px',
	fillColor : 'rgba(34, 190, 239, .3)',
	lineColor : 'rgba(34, 190, 239, .5)',
	lineWidth : 2,
	minSpotColor : '#eaf9fe',
	maxSpotColor : '#00a3d8',
	highlightSpotColor : '#00a3d8',
	highlightLineColor : '#bec6ca',
	spotRadius : 5,
	valueSpots : [ 1, 6, 8, 7, 6, 8, 5, 4, 5 ],

	normalRangeMin : 0
});

